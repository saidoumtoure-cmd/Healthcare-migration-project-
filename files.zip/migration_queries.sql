-- ============================================================
-- Healthcare Data Migration Project
-- SQL Queries: Schema Creation, Staging, Validation & Migration
-- Database: PostgreSQL-compatible
-- ============================================================


-- ============================================================
-- 1. LEGACY SYSTEM TABLE (source)
-- ============================================================

CREATE TABLE IF NOT EXISTS legacy_patients (
    patient_id          VARCHAR(10)  PRIMARY KEY,
    old_name            VARCHAR(150),
    dob                 VARCHAR(20),          -- intentionally VARCHAR (inconsistent formats)
    address             TEXT,
    phone_number        VARCHAR(30),
    email               VARCHAR(150),
    registration_date   VARCHAR(20),
    insurance_provider  VARCHAR(80),
    blood_type          VARCHAR(5),
    primary_physician   VARCHAR(100)
);


-- ============================================================
-- 2. NEW SYSTEM TABLE (target)
-- ============================================================

CREATE TABLE IF NOT EXISTS new_patients (
    new_patient_id      VARCHAR(10)  PRIMARY KEY,
    legacy_id           VARCHAR(10),
    full_name           VARCHAR(150)  NOT NULL,
    date_of_birth       DATE          NOT NULL,
    mailing_address     TEXT,
    contact_phone       VARCHAR(20),
    contact_email       VARCHAR(150),
    enrollment_date     DATE,
    payer_name          VARCHAR(80)   DEFAULT 'Unknown',
    blood_group         VARCHAR(5),
    attending_physician VARCHAR(100),
    migrated_at         TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    data_quality_flag   VARCHAR(20)   DEFAULT 'COMPLETE',
    CONSTRAINT chk_email CHECK (contact_email LIKE '%@%.%' OR contact_email IS NULL),
    CONSTRAINT chk_dob   CHECK (date_of_birth BETWEEN '1900-01-01' AND CURRENT_DATE)
);


-- ============================================================
-- 3. FIELD MAPPING REFERENCE TABLE
-- ============================================================

CREATE TABLE IF NOT EXISTS field_mapping_reference (
    mapping_id       SERIAL PRIMARY KEY,
    legacy_field     VARCHAR(80),
    new_field        VARCHAR(80),
    transformation   TEXT,
    data_type_legacy VARCHAR(40),
    data_type_new    VARCHAR(40),
    nullable         BOOLEAN
);

INSERT INTO field_mapping_reference
    (legacy_field, new_field, transformation, data_type_legacy, data_type_new, nullable)
VALUES
    ('patient_id',        'legacy_id',          'Preserved as reference; new_patient_id generated (NP#####)',       'VARCHAR(10)',  'VARCHAR(10)',  FALSE),
    ('old_name',          'full_name',           'Normalized: LAST, FIRST and ALL CAPS → Title Case First Last',    'VARCHAR(150)', 'VARCHAR(150)', FALSE),
    ('dob',               'date_of_birth',       'ISO 8601 (YYYY-MM-DD); parsed from MM/DD/YYYY and YYYY/MM/DD',   'VARCHAR(20)',  'DATE',         FALSE),
    ('address',           'mailing_address',     'Trimmed whitespace; NULL kept where missing',                     'TEXT',         'TEXT',         TRUE),
    ('phone_number',      'contact_phone',       'Normalized to (XXX) XXX-XXXX; invalid numbers set to NULL',      'VARCHAR(30)',  'VARCHAR(20)',  TRUE),
    ('email',             'contact_email',       'Lowercased; regex-validated; invalid entries set to NULL',        'VARCHAR(150)', 'VARCHAR(150)', TRUE),
    ('registration_date', 'enrollment_date',     'ISO 8601 (YYYY-MM-DD); parsed from multiple legacy formats',     'VARCHAR(20)',  'DATE',         TRUE),
    ('insurance_provider','payer_name',          'NULL values filled with ''Unknown''',                             'VARCHAR(80)',  'VARCHAR(80)',  FALSE),
    ('blood_type',        'blood_group',         'No transformation required; values were consistent',              'VARCHAR(5)',   'VARCHAR(5)',   TRUE),
    ('primary_physician', 'attending_physician', 'No transformation required',                                      'VARCHAR(100)','VARCHAR(100)', TRUE),
    ('(generated)',       'new_patient_id',      'Sequential ID: NP00001, NP00002, … generated during migration',  'N/A',         'VARCHAR(10)',  FALSE),
    ('(generated)',       'migrated_at',         'UTC timestamp stamped at migration run time',                     'N/A',         'TIMESTAMP',    FALSE),
    ('(generated)',       'data_quality_flag',   'COMPLETE / INCOMPLETE based on phone + email presence',          'N/A',         'VARCHAR(20)',  FALSE);


-- ============================================================
-- 4. DATA QUALITY VALIDATION QUERIES
-- ============================================================

-- 4a. Record counts
SELECT
    'legacy_patients (raw)'      AS source,
    COUNT(*)                     AS record_count
FROM legacy_patients
UNION ALL
SELECT
    'new_patients (post-migration)',
    COUNT(*)
FROM new_patients;

-- 4b. Duplicate check on legacy data (name + dob)
SELECT
    old_name,
    dob,
    COUNT(*) AS occurrences
FROM legacy_patients
GROUP BY old_name, dob
HAVING COUNT(*) > 1
ORDER BY occurrences DESC;

-- 4c. Null / missing value audit (new system)
SELECT
    COUNT(*)                                             AS total_records,
    SUM(CASE WHEN mailing_address     IS NULL THEN 1 ELSE 0 END) AS missing_address,
    SUM(CASE WHEN contact_phone       IS NULL THEN 1 ELSE 0 END) AS missing_phone,
    SUM(CASE WHEN contact_email       IS NULL THEN 1 ELSE 0 END) AS missing_email,
    SUM(CASE WHEN data_quality_flag = 'INCOMPLETE' THEN 1 ELSE 0 END) AS incomplete_records
FROM new_patients;

-- 4d. Date of birth sanity check (no future DOBs, no unreasonably old)
SELECT *
FROM new_patients
WHERE date_of_birth > CURRENT_DATE
   OR date_of_birth < '1900-01-01';

-- 4e. Duplicate check on cleaned data (should return 0 rows)
SELECT
    full_name,
    date_of_birth,
    COUNT(*) AS occurrences
FROM new_patients
GROUP BY full_name, date_of_birth
HAVING COUNT(*) > 1;

-- 4f. Payer distribution summary
SELECT
    payer_name,
    COUNT(*)                                AS patient_count,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 1) AS pct
FROM new_patients
GROUP BY payer_name
ORDER BY patient_count DESC;

-- 4g. Data quality flag breakdown
SELECT
    data_quality_flag,
    COUNT(*) AS count
FROM new_patients
GROUP BY data_quality_flag;


-- ============================================================
-- 5. ETL MIGRATION INSERT (legacy → new system)
--    Run after Python cleaning pipeline populates staging CSV
-- ============================================================

/*
  In practice, load the clean CSV into a staging table first:
      COPY staging_clean_patients FROM '/path/clean_patients_new_system.csv' CSV HEADER;
  Then insert into the target table:
*/

INSERT INTO new_patients (
    new_patient_id, legacy_id, full_name, date_of_birth,
    mailing_address, contact_phone, contact_email,
    enrollment_date, payer_name, blood_group,
    attending_physician, data_quality_flag
)
SELECT
    new_patient_id,
    legacy_id,
    full_name,
    date_of_birth::DATE,
    mailing_address,
    contact_phone,
    contact_email,
    enrollment_date::DATE,
    COALESCE(payer_name, 'Unknown'),
    blood_group,
    attending_physician,
    data_quality_flag
FROM staging_clean_patients
ON CONFLICT (new_patient_id) DO NOTHING;   -- idempotent: safe to re-run


-- ============================================================
-- 6. POST-MIGRATION RECONCILIATION
-- ============================================================

-- Row count match assertion (expect 80)
DO $$
DECLARE
    v_count INT;
BEGIN
    SELECT COUNT(*) INTO v_count FROM new_patients;
    ASSERT v_count = 80,
        FORMAT('Migration row count mismatch: expected 80, got %s', v_count);
    RAISE NOTICE 'Row count check PASSED: % records', v_count;
END $$;

-- Referential integrity: every legacy_id maps 1-to-1
SELECT
    legacy_id,
    COUNT(*) AS occurrences
FROM new_patients
GROUP BY legacy_id
HAVING COUNT(*) > 1;  -- should return 0 rows
